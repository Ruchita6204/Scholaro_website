function startPreparing() {
  alert("Redirecting to preparation modules...");
}

function toggleMenu() {
  const navLinks = document.getElementById("navLinks");
  navLinks.classList.toggle("active");
}